import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class refreshDto {
  @ApiProperty({ example: 'tokenId.tokenSecret' })
  @IsString()
  refreshToken!: string;
}
